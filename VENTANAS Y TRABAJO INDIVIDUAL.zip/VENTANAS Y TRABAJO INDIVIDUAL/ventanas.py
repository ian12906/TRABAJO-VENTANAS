import tkinter as tk
from tkinter import PhotoImage
from tkinter import ttk
from turtle import st
from ttkthemes import ThemedTk
import math
import sys
from tkinter import scrolledtext as st
from tkinter import filedialog as fd
from tkinter import messagebox

# Función para calcular el área según la figura seleccionada
def mostrar_campos_figura(event):
    figura = combo.get()
    limpiar_campos()

    if figura == "Cuadrado":
        label_1.config(text="Lado:")
        label_1.pack(pady=5)
        entry_1.pack(pady=5)
        boton_area.pack(pady=10)

    elif figura == "Rectángulo":
        label_1.config(text="Base:")
        label_2.config(text="Altura:")
        label_1.pack(pady=5)
        entry_1.pack(pady=5)
        label_2.pack(pady=5)
        entry_2.pack(pady=5)
        boton_area.pack(pady=10)

    elif figura == "Triángulo":
        label_1.config(text="Base:")
        label_2.config(text="Altura:")
        label_1.pack(pady=5)
        entry_1.pack(pady=5)
        label_2.pack(pady=5)
        entry_2.pack(pady=5)
        boton_area.pack(pady=10)

    elif figura == "Círculo":
        label_1.config(text="Radio:")
        label_1.pack(pady=5)
        entry_1.pack(pady=5)
        boton_area.pack(pady=10)

    elif figura == "Polígono Regular":
        label_1.config(text="Perímetro:")
        label_2.config(text="Apotema:")
        label_1.pack(pady=5)
        entry_1.pack(pady=5)
        label_2.pack(pady=5)
        entry_2.pack(pady=5)
        boton_area.pack(pady=10)

def calcular_area():
    figura = combo.get()
    try:
        if figura == "Cuadrado":
            lado = float(entry_1.get())
            area = lado ** 2
        elif figura == "Rectángulo":
            base = float(entry_1.get())
            altura = float(entry_2.get())
            area = base * altura
        elif figura == "Triángulo":
            base = float(entry_1.get())
            altura = float(entry_2.get())
            area = 0.5 * base * altura
        elif figura == "Círculo":
            radio = float(entry_1.get())
            area = math.pi * (radio ** 2)
        elif figura == "Polígono Regular":
            perimetro = float(entry_1.get())
            apotema = float(entry_2.get())
            area = (perimetro * apotema) / 2
        resultado.config(text=f"Área: {area:.2f}")
    except ValueError:
        messagebox.showerror("Error", "Por favor ingrese valores numéricos válidos")

def limpiar_campos():
    label_1.pack_forget()
    label_2.pack_forget()
    entry_1.pack_forget()
    entry_2.pack_forget()
    entry_1.delete(0, tk.END)
    entry_2.delete(0, tk.END)
    boton_area.pack_forget()
    resultado.config(text="Área:")

# Funciones de la calculadora básica
def click_boton(item):
    global expresion
    expresion += str(item)
    input_text.set(expresion)

def calcular():
    global expresion
    try:
        resultado = str(eval(expresion))
        input_text.set(resultado)
        expresion = resultado
    except:
        input_text.set("Error")
        expresion = ""

def limpiar():
    global expresion
    expresion = ""
    input_text.set("")

# Función para la barra de progreso
def update_progress():
    progress["value"] = 0
    step_progress()

def step_progress():
    if progress["value"] < 100:
        progress["value"] += 10
        root.after(900, step_progress)
    else:
        root.destroy()

# Crear ventana principal
root = ThemedTk(theme="adapta")
root.title("Aplicación Completa")
root.geometry("1000x800")

notebook = ttk.Notebook(root)
notebook.pack(pady=10, expand=True)

# Pestaña 1: Calculadora de Áreas
frame1 = ttk.Frame(notebook)
notebook.add(frame1, text="Calculadora de Áreas")

label_figura = ttk.Label(frame1, text="Seleccione la figura:")
label_figura.pack(pady=5)

combo = ttk.Combobox(frame1, values=[
                     "Cuadrado", "Rectángulo", "Triángulo", "Círculo", "Polígono Regular"], state="readonly")
combo.pack(pady=5)
combo.bind("<<ComboboxSelected>>", mostrar_campos_figura)

label_1 = ttk.Label(frame1)
label_2 = ttk.Label(frame1)
entry_1 = ttk.Entry(frame1)
entry_2 = ttk.Entry(frame1)

boton_area = ttk.Button(frame1, text="Calcular Área", command=calcular_area)
boton_area.pack(pady=10)  

resultado = ttk.Label(frame1, text="Área:")
resultado.pack(pady=5)

# Pestaña 2: Calculadora Básica
frame2 = ttk.Frame(notebook)
notebook.add(frame2, text='Calculadora Básica')

expresion = ""
input_text = tk.StringVar()

pantalla = tk.Entry(frame2, textvariable=input_text, font=(
    'arial', 18, 'bold'), bd=20, insertwidth=4, width=14, borderwidth=4, justify="right")
pantalla.grid(row=0, column=0, columnspan=4, pady=10)  

# Botones de la calculadora
botones = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('C', 4, 0), ('0', 4, 1), ('=', 4, 2), ('+', 4, 3)
]

for (text, row, column) in botones:
    if text == '=':
        tk.Button(frame2, text=text, width=10, height=3, command=calcular).grid(row=row, column=column)
    elif text == 'C':
        tk.Button(frame2, text=text, width=10, height=3, command=limpiar).grid(row=row, column=column)
    else:
        tk.Button(frame2, text=text, width=10, height=3, command=lambda b=text: click_boton(b)).grid(row=row, column=column)

# Pestaña 3: TRABAJO INDIVIDUAL
frame3 = ttk.Frame(notebook)
notebook.add(frame3, text="TRABAJO INDIVIDUAL")

class Aplicacion:
    def __init__(self):
        self.ventana1 = tk.Toplevel()  
        self.agregar_menu()
        self.scrolledtext1 = st.ScrolledText(self.ventana1, width=80, height=20)
        self.scrolledtext1.pack(padx=10, pady=10)
        self.ventana1.protocol("WM_DELETE_WINDOW", self.salir)  
        self.ventana1.mainloop()

    def agregar_menu(self):
        menubar1 = tk.Menu(self.ventana1)
        self.ventana1.config(menu=menubar1)
        opciones1 = tk.Menu(menubar1, tearoff=0)

        opciones1.add_command(label="Abrir", command=self.recuperar)
        opciones1.add_separator()
        opciones1.add_command(label="Salir", command=self.salir)
        menubar1.add_cascade(label="Archivo", menu=opciones1)

    def salir(self):
        self.ventana1.destroy()  # Cierra la ventana correctamente
        sys.exit()

    def recuperar(self):
        nombrearch = fd.askopenfilename(initialdir="/", title="Seleccione archivo", filetypes=(
            ("Archivos de texto", "*.txt"), ("Todos los archivos", "*.*")))
        if nombrearch:
            try:
                with open(nombrearch, "r", encoding="utf-8") as archi1:
                    contenido = archi1.read()
                    self.scrolledtext1.delete("1.0", tk.END)
                    self.scrolledtext1.insert("1.0", contenido)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el archivo: {e}")

# Crear un botón para abrir la nueva ventana
abrirarchivo = tk.Button(frame3, text="Abrir archivo", command=lambda: Aplicacion())
abrirarchivo.pack(pady=20)

# Pestaña 4: Integrantes
frame4 = ttk.Frame(notebook)
notebook.add(frame4, text="Integrantes")

# Cargar imágenes
imagen = PhotoImage(file=r"C:\Users\ian\Desktop\python\INTEGRANTES\rap.png")
imagen1 = PhotoImage(file=r"C:\Users\ian\Desktop\python\INTEGRANTES\goku.png")
imagen2 = PhotoImage(file=r"C:\Users\ian\Desktop\python\INTEGRANTES\gato.png")
imagen3 = PhotoImage(file=r"C:\Users\ian\Desktop\python\INTEGRANTES\jk.png")

# Títulos
tk.Label(frame4, text='NOMBRES').grid(row=0, column=0, padx=5, pady=5)
tk.Label(frame4, text='MATRICULAS').grid(row=0, column=1, padx=5, pady=5)
tk.Label(frame4, text='NUMERO DE LISTA').grid(row=0, column=2, padx=5, pady=5)
tk.Label(frame4, text='IMAGENES').grid(row=0, column=3, padx=5, pady=5)

# Integrantes
integrantes = [
    ('IAN MISAEL MOYOTL MOYOTL', '231403044', '13', imagen),
    ('JUAN JOSE BAUTISTA ESPINOSA', '231403169', '1', imagen1),
    ('CARLOS CASTRO CERECEDO', '231403001', '3', imagen2),
    ('PAOLA LESAMA SALAS', '231403009', '9', imagen3)
]

for i, (nombre, matricula, lista, imagen) in enumerate(integrantes):
    tk.Label(frame4, text=nombre).grid(row=i+1, column=0, padx=5, pady=5)
    tk.Label(frame4, text=matricula).grid(row=i+1, column=1, padx=5, pady=5)
    tk.Label(frame4, text=lista).grid(row=i+1, column=2, padx=5, pady=5)
    tk.Label(frame4, image=imagen).grid(row=i+1, column=3, padx=5, pady=5)

# Barra de progreso
progress = ttk.Progressbar(frame4, orient="horizontal", length=400, mode="determinate")
progress.grid(row=len(integrantes)+1, column=0, columnspan=4, pady=20)

# Botón para iniciar la barra de progreso
start_button = tk.Button(frame4, text="Iniciar", command=update_progress)
start_button.grid(row=len(integrantes)+2, column=0, columnspan=4)

# Ejecutar la aplicación
root.mainloop()
